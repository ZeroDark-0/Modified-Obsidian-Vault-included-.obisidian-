# Obsidian Vault Template

[Based on CyanVoxel's template v1.2.0](https://github.com/CyanVoxel/Obsidian-Vault-Template) / [Vault Tour](https://youtu.be/rAkerV8rlow)

## A Template for my Obsidian Vault.

This vault contains several CyanVoxel snippets, which you can find in their own (and updated) repositories here:

- [Colored Sidebar](https://github.com/CyanVoxel/Obsidian-Colored-Sidebar)
- [Daily Themes](https://github.com/CyanVoxel/Obsidian-Daily-Themes)
- [Notebook Themes](https://github.com/CyanVoxel/Obsidian-Notebook-Themes)
- [Game Themes](https://github.com/CyanVoxel/Obsidian-Game-Themes)

...as well as eventually a few of my own as I start using the tool more actively.
