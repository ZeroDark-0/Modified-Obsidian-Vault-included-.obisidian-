---
date: <% tp.file.creation_date() %>
type: meeting
aliases: 
area: 
project: 
participants: 
summary: 
tags:
  - Meeting
---

<% await tp.file.rename(tp.date.now("YYYY-MM-DD") + " " + tp.file.title) %>
# [[<% tp.date.now("YYYY-MM-DD") + " " + tp.file.title %>]]

TODO

## Agenda

* TODO

## Notes

* TODO

## Action Items

* TODO
