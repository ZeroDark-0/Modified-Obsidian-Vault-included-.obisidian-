---
status: 🟥🟨🟩
tags:
  - project
links: 
deadline: <% tp.date.now("YYYY-MM-DD") %>
area: [[My Areas]]
---
## Related Resources

```dataview
LIST
FROM [[]] AND #resource
```
