---
tags:
  - area
links: 
deadline: <% tp.date.now("YYYY-MM-DD") %>
area: [[My Areas]]
---
## Related Projects

```dataview
TABLE status, deadline
FROM [[]] AND #project
```
